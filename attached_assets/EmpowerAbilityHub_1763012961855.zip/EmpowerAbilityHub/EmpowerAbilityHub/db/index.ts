// db/index.ts
import 'dotenv/config';
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "@shared/schema"; // adjust path if needed

if (!process.env.DATABASE_URL) {
  throw new Error("❌ DATABASE_URL must be set. Did you forget to create your .env file?");
}

const connect = async () => {
  try {
    // Connect to MySQL
    const connection = await mysql.createConnection(process.env.DATABASE_URL);
    console.log("✅ Connected to MySQL database successfully.");

    // Initialize drizzle ORM
    const dbInstance = drizzle(connection, { schema });
    return dbInstance;
  } catch (error) {
    console.error("❌ Database connection failed:", error);
    process.exit(1);
  }
};

// Create a promise that resolves to the db instance
export const dbPromise = connect();

// Optional helper for awaiting connection before queries
export const getDB = async () => await dbPromise;
