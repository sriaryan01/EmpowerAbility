import { useRoute, useLocation } from "wouter";
import { SchemeDetail } from "@/components/SchemeDetail";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const mockSchemes = [
  {
    id: "1",
    title: "Disability Pension and Financial Assistance",
    description: "This comprehensive scheme provides monthly financial support for persons with disabilities to meet their basic living expenses and healthcare needs. The scheme ensures financial security and dignity for persons with disabilities through regular monetary assistance. The program has been helping millions of PWDs across the country maintain financial independence and access essential services.",
    category: "Financial Support",
    deadline: "2026-12-31",
    eligibility: "Persons with 40% or more disability as certified by a competent medical authority. Annual family income should be below ₹2 lakh. Applicants must hold a valid disability certificate issued by the designated medical board. The scheme covers all types of disabilities including physical, visual, hearing, intellectual, and multiple disabilities.",
    benefits: "Monthly pension ranging from ₹1,500 to ₹3,000 based on the severity of disability and state-specific guidelines. Direct bank transfer on the first of every month. Additional benefits include waiver of electricity bill charges, free travel passes for public transport, and priority in government welfare programs. Special provisions for persons with severe disabilities (80% or more) with enhanced pension amounts.",
    status: "active" as const,
  },
  {
    id: "2",
    title: "Assistive Devices and Equipment Scheme",
    description: "A vital scheme providing free assistive devices and equipment to enhance mobility, communication, and independence for persons with disabilities. The program covers a wide range of aids and appliances including wheelchairs, hearing aids, artificial limbs, visual aids, and other assistive technologies. The scheme has distributed over 1 million devices across the country, significantly improving the quality of life for PWDs.",
    category: "Healthcare",
    deadline: "2026-06-30",
    eligibility: "All persons with disabilities certified by a medical board are eligible. Annual family income should be below ₹3 lakh. Priority is given to persons with severe disabilities and those who cannot afford assistive devices. Applicants must provide a disability certificate, income certificate, and a prescription from a qualified medical professional specifying the required assistive device.",
    benefits: "Free provision of assistive devices worth up to ₹1 lakh per person. Devices include motorized and manual wheelchairs, hearing aids (digital and analog), white canes, tricycles for lower limb disabilities, artificial limbs and calipers, braille equipment, speech therapy aids, and mobility aids. Free maintenance and repairs for 3 years. Replacement of devices after 5 years of use. Doorstep delivery and fitting services for severely disabled persons.",
    status: "active" as const,
  },
];

export default function SchemeDetailPage() {
  const [, params] = useRoute("/schemes/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const scheme = mockSchemes.find((s) => s.id === params?.id);

  if (!scheme) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Scheme Not Found</h2>
        <p className="text-muted-foreground mb-6">
          The scheme you're looking for doesn't exist.
        </p>
        <Button onClick={() => setLocation("/schemes")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Schemes
        </Button>
      </div>
    );
  }

  const handleDelete = () => {
    toast({
      title: "Scheme deleted",
      description: "The scheme has been successfully deleted.",
    });
    setTimeout(() => setLocation("/schemes"), 1000);
  };

  return (
    <div>
      <Button
        variant="ghost"
        onClick={() => setLocation("/schemes")}
        className="mb-6"
        data-testid="button-back"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Schemes
      </Button>
      <SchemeDetail scheme={scheme} onDelete={handleDelete} />
    </div>
  );
}
