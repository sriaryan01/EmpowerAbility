import { useRoute, useLocation } from "wouter";
import { SchemeForm } from "@/components/SchemeForm";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SchemeFormPage() {
  const [, params] = useRoute("/schemes/:id/edit");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const isEdit = params?.id !== "new";

  const handleSubmit = (data: any) => {
    console.log("Scheme submitted:", data);
    toast({
      title: isEdit ? "Scheme updated" : "Scheme created",
      description: isEdit
        ? "The scheme has been successfully updated."
        : "The new scheme has been successfully created.",
    });
    setTimeout(() => setLocation("/schemes"), 1000);
  };

  const handleCancel = () => {
    setLocation("/schemes");
  };

  return (
    <div className="max-w-4xl">
      <Button
        variant="ghost"
        onClick={handleCancel}
        className="mb-6"
        data-testid="button-back"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Schemes
      </Button>
      <SchemeForm onSubmit={handleSubmit} onCancel={handleCancel} />
    </div>
  );
}
