import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Calendar } from "lucide-react";
import { Link } from "wouter";

export default function Applications() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">
          My Applications
        </h1>
        <p className="text-muted-foreground text-lg">
          Track the status of your scheme applications
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Application Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <div className="mx-auto h-24 w-24 rounded-full bg-muted flex items-center justify-center mb-4">
              <FileText className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2" data-testid="text-no-applications">
              No Applications Yet
            </h3>
            <p className="text-muted-foreground mb-6">
              You haven't applied to any schemes yet. Browse disability-specific schemes and start your benefit application process.
            </p>
            <Button asChild data-testid="button-browse-schemes">
              <Link href="/schemes">Browse Schemes</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>How to Apply</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
              1
            </div>
            <div>
              <h4 className="font-semibold mb-1">Browse Schemes</h4>
              <p className="text-sm text-muted-foreground">
                Explore disability-specific schemes and find ones that match your disability type and eligibility criteria.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
              2
            </div>
            <div>
              <h4 className="font-semibold mb-1">Review Details</h4>
              <p className="text-sm text-muted-foreground">
                Read the eligibility criteria, benefits, and application process carefully.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
              3
            </div>
            <div>
              <h4 className="font-semibold mb-1">Submit Application</h4>
              <p className="text-sm text-muted-foreground">
                Click "Apply Now" and complete the application form with required documents.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
              4
            </div>
            <div>
              <h4 className="font-semibold mb-1">Track Status</h4>
              <p className="text-sm text-muted-foreground">
                Monitor your application status here and receive updates on approval.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
