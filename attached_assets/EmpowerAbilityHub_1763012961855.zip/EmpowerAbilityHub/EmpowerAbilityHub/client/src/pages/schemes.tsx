import { SchemesList } from "@/components/SchemesList";

const mockSchemes = [
  {
    id: "1",
    title: "Disability Pension and Financial Assistance",
    description: "Monthly financial support for persons with disabilities to meet their basic living expenses and healthcare needs. The scheme provides regular monetary assistance to ensure financial security.",
    category: "Financial Support",
    deadline: "2026-12-31",
    eligibility: "Persons with 40% or more disability, certified by medical authority, with annual family income below ₹2 lakh",
    benefits: "Monthly pension of ₹1,500-₹3,000 based on severity of disability and state guidelines",
    status: "active" as const,
  },
  {
    id: "2",
    title: "Assistive Devices and Equipment Scheme",
    description: "Free provision of assistive devices and equipment to enhance mobility and independence for persons with disabilities including wheelchairs, hearing aids, artificial limbs, and visual aids.",
    category: "Healthcare",
    deadline: "2026-06-30",
    eligibility: "Persons with disabilities certified by medical board, with family income below ₹3 lakh annually",
    benefits: "Free assistive devices worth up to ₹1 lakh including wheelchairs, hearing aids, white canes, tricycles, and artificial limbs",
    status: "active" as const,
  },
  {
    id: "3",
    title: "Special Education and Scholarship Program",
    description: "Educational support including scholarships, free books, and special education services for students with disabilities from pre-primary to post-graduate levels.",
    category: "Education",
    deadline: "2025-09-30",
    eligibility: "Students with disabilities (minimum 40% disability) enrolled in recognized educational institutions",
    benefits: "Annual scholarship ₹10,000-₹50,000 based on education level, free textbooks, special educator support, and assistive technology",
    status: "active" as const,
  },
  {
    id: "4",
    title: "Employment Skills Training and Job Placement",
    description: "Vocational training and job placement assistance specifically designed for persons with disabilities, with employer incentives for inclusive hiring.",
    category: "Employment",
    deadline: "2026-03-31",
    eligibility: "Persons with disabilities aged 18-45, with minimum 8th standard education",
    benefits: "Free skill training for 6 months, job placement support, ₹3,000 monthly stipend during training, and employer incentives",
    status: "active" as const,
  },
  {
    id: "5",
    title: "Accessible Housing and Home Modification",
    description: "Financial assistance for purchasing accessible homes or modifying existing homes with ramps, accessible bathrooms, and other necessary adaptations for persons with disabilities.",
    category: "Housing",
    deadline: "2026-12-31",
    eligibility: "Persons with mobility disabilities with family income below ₹6 lakh, owning a home or planning to purchase",
    benefits: "Grant up to ₹2 lakh for home modifications or ₹4 lakh interest subsidy on accessible housing loans",
    status: "active" as const,
  },
  {
    id: "6",
    title: "Healthcare and Rehabilitation Services",
    description: "Comprehensive healthcare coverage including free medical treatment, surgeries, therapies, and rehabilitation services at empaneled hospitals and centers.",
    category: "Healthcare",
    deadline: "2026-12-31",
    eligibility: "All persons with disabilities holding valid disability certificate",
    benefits: "Free treatment up to ₹5 lakh annually, free physiotherapy, speech therapy, occupational therapy, and specialized consultations",
    status: "active" as const,
  },
  {
    id: "7",
    title: "Entrepreneurship Development for PWDs",
    description: "Special loans and grants for persons with disabilities to start their own businesses, with mentorship and marketing support.",
    category: "Employment",
    deadline: "2025-12-31",
    eligibility: "Persons with disabilities aged 21-60 with viable business plan",
    benefits: "Loan up to ₹10 lakh at 4% interest, ₹50,000 subsidy, free business training, and dedicated mentorship for 2 years",
    status: "active" as const,
  },
  {
    id: "8",
    title: "Transportation Concessions and Mobility Support",
    description: "Travel concessions and support for persons with disabilities using public transport, railways, and air travel.",
    category: "Transportation",
    deadline: "2026-12-31",
    eligibility: "Persons with disabilities holding valid disability certificate",
    benefits: "75% discount on rail travel, 50% on air travel (domestic), free/subsidized bus passes, and companion travel allowance",
    status: "active" as const,
  },
  {
    id: "9",
    title: "Disability Certificate Issuance Support",
    description: "Fast-track processing and assistance for obtaining disability certificates from certified medical boards with doorstep service for severely disabled persons.",
    category: "Documentation",
    deadline: "2026-12-31",
    eligibility: "All persons with disabilities requiring certification",
    benefits: "Free medical assessment, doorstep service for severely disabled, certificate issued within 15 days",
    status: "active" as const,
  },
  {
    id: "10",
    title: "Sports and Recreation Programs for PWDs",
    description: "Support for participation in sports, recreation, and cultural activities including training, equipment, and competition expenses.",
    category: "Sports & Recreation",
    deadline: "2025-10-31",
    eligibility: "Persons with disabilities interested in sports and cultural activities",
    benefits: "Free sports equipment, coaching support, travel allowance for competitions, and participation in national/international events",
    status: "active" as const,
  },
  {
    id: "11",
    title: "Caregiver Support and Respite Care",
    description: "Financial assistance and respite care services for families and caregivers of persons with severe disabilities.",
    category: "Caregiver Support",
    deadline: "2026-06-30",
    eligibility: "Families caring for persons with severe disabilities (80% or more)",
    benefits: "Monthly caregiver allowance of ₹2,000, respite care services, and training on disability care",
    status: "active" as const,
  },
  {
    id: "12",
    title: "Legal Aid and Rights Awareness Program",
    description: "Free legal assistance for persons with disabilities to ensure their rights are protected, with awareness programs on disability rights and laws.",
    category: "Legal Support",
    deadline: "2026-12-31",
    eligibility: "All persons with disabilities",
    benefits: "Free legal consultation, representation in court, and awareness workshops on disability rights and benefits",
    status: "active" as const,
  },
];

export default function Schemes() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">
          Schemes for Persons with Disabilities
        </h1>
        <p className="text-muted-foreground text-lg">
          Browse and search through all available government schemes and benefits
        </p>
      </div>
      <SchemesList schemes={mockSchemes} />
    </div>
  );
}
