import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accessibility, Volume2, Contrast, Info } from "lucide-react";

export default function About() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">
          About EmpowerAbility
        </h1>
        <p className="text-muted-foreground text-lg">
          Learn about our mission and accessibility features
        </p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Our Mission
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              EmpowerAbility is a comprehensive portal dedicated to making government schemes and benefits
              for Persons with Disabilities (PWDs) accessible to everyone. We believe that information about
              disability-specific benefits and opportunities should be easy to find, understand, and apply for,
              regardless of physical or technological barriers.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Our platform brings together various government schemes across categories including financial
              support, healthcare, education, employment, housing, assistive devices, and legal aid,
              providing a centralized hub for PWDs and their families to discover and apply for programs
              designed to support independent living and equal opportunities.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Accessibility className="h-5 w-5" />
              Accessibility Features
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-muted-foreground leading-relaxed">
              We've built EmpowerAbility with accessibility at its core. Our platform includes several
              features to ensure everyone can access government schemes information:
            </p>

            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Volume2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Text-to-Speech</h4>
                  <p className="text-sm text-muted-foreground">
                    Enable text-to-speech to have scheme details and content read aloud. Click the speaker
                    icon on any scheme card or use the global toggle in the header to enable this feature
                    across the entire application.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Contrast className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">High Contrast Mode</h4>
                  <p className="text-sm text-muted-foreground">
                    Switch to high contrast mode for improved readability with enhanced color contrast
                    between text and backgrounds. This feature is especially helpful for users with visual
                    impairments or those working in bright environments.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Accessibility className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Keyboard Navigation</h4>
                  <p className="text-sm text-muted-foreground">
                    Navigate the entire portal using only your keyboard. All interactive elements are
                    accessible via Tab key navigation, with clear focus indicators to show your current
                    position on the page.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Accessibility className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Screen Reader Support</h4>
                  <p className="text-sm text-muted-foreground">
                    Full compatibility with popular screen readers including NVDA, JAWS, and VoiceOver.
                    All content is properly labeled with ARIA attributes to ensure accurate navigation and
                    content reading.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Getting Help</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              If you need assistance navigating the portal or have questions about any scheme, please
              contact our support team. We're here to help ensure you can access all the information and
              opportunities available to you.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
