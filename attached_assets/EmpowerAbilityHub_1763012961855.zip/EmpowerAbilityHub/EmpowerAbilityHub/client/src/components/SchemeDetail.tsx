import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Calendar, Users, Award, FileText, Volume2, Edit, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useAccessibility } from "./AccessibilityContext";
import type { Scheme } from "./SchemeCard";

interface SchemeDetailProps {
  scheme: Scheme;
  onDelete?: () => void;
}

export function SchemeDetail({ scheme, onDelete }: SchemeDetailProps) {
  const { speak } = useAccessibility();

  const handleSpeak = () => {
    const text = `${scheme.title}. ${scheme.description}. Eligibility: ${scheme.eligibility}. Benefits: ${scheme.benefits}. Deadline: ${new Date(scheme.deadline).toLocaleDateString()}.`;
    speak(text);
  };

  const statusColor = {
    active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    closed: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400",
    upcoming: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
            <div className="space-y-2">
              <CardTitle className="text-3xl font-bold" data-testid="text-scheme-title">
                {scheme.title}
              </CardTitle>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" data-testid="badge-category">
                  {scheme.category}
                </Badge>
                <Badge className={statusColor[scheme.status]} data-testid="badge-status">
                  {scheme.status}
                </Badge>
              </div>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={handleSpeak}
              aria-label="Read scheme details"
              data-testid="button-speak-details"
            >
              <Volume2 className="h-5 w-5" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Overview
              </h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-description">
                {scheme.description}
              </p>
            </div>

            <Separator />

            <div>
              <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Users className="h-5 w-5" />
                Eligibility
              </h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-eligibility">
                {scheme.eligibility}
              </p>
            </div>

            <Separator />

            <div>
              <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Award className="h-5 w-5" />
                Benefits
              </h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-benefits">
                {scheme.benefits}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <Card className="sticky top-4">
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" size="lg" data-testid="button-apply">
              Apply Now
            </Button>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span data-testid="text-deadline">
                Deadline: {new Date(scheme.deadline).toLocaleDateString()}
              </span>
            </div>
            <Separator />
            <div className="space-y-2">
              <Button variant="outline" className="w-full" asChild data-testid="button-edit">
                <Link href={`/schemes/${scheme.id}/edit`}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Scheme
                </Link>
              </Button>
              <Button
                variant="destructive"
                className="w-full"
                onClick={onDelete}
                data-testid="button-delete"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Scheme
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
