import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Scheme } from "./SchemeCard";

const schemeFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Please select a category"),
  deadline: z.string().min(1, "Deadline is required"),
  eligibility: z.string().min(10, "Eligibility criteria must be at least 10 characters"),
  benefits: z.string().min(10, "Benefits must be at least 10 characters"),
  status: z.enum(["active", "closed", "upcoming"]),
});

type SchemeFormData = z.infer<typeof schemeFormSchema>;

interface SchemeFormProps {
  scheme?: Scheme;
  onSubmit: (data: SchemeFormData) => void;
  onCancel: () => void;
}

const categories = [
  "Financial Support",
  "Healthcare",
  "Education",
  "Employment",
  "Housing",
  "Transportation",
  "Assistive Devices",
  "Legal Support",
  "Caregiver Support",
  "Sports & Recreation",
  "Documentation",
];

export function SchemeForm({ scheme, onSubmit, onCancel }: SchemeFormProps) {
  const form = useForm<SchemeFormData>({
    resolver: zodResolver(schemeFormSchema),
    defaultValues: scheme
      ? {
          title: scheme.title,
          description: scheme.description,
          category: scheme.category,
          deadline: scheme.deadline,
          eligibility: scheme.eligibility,
          benefits: scheme.benefits,
          status: scheme.status,
        }
      : {
          title: "",
          description: "",
          category: "",
          deadline: "",
          eligibility: "",
          benefits: "",
          status: "upcoming",
        },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl" data-testid="text-form-title">
          {scheme ? "Edit Scheme" : "Create New Scheme"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter scheme title"
                      {...field}
                      data-testid="input-title"
                      aria-required="true"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the scheme..."
                      className="min-h-24"
                      {...field}
                      data-testid="input-description"
                      aria-required="true"
                    />
                  </FormControl>
                  <FormDescription>Provide a comprehensive overview of the scheme</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-category" aria-required="true">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="deadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deadline *</FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        {...field}
                        data-testid="input-deadline"
                        aria-required="true"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="eligibility"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Eligibility Criteria *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Who can apply for this scheme?"
                      className="min-h-20"
                      {...field}
                      data-testid="input-eligibility"
                      aria-required="true"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="benefits"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Benefits *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="What benefits does this scheme provide?"
                      className="min-h-20"
                      {...field}
                      data-testid="input-benefits"
                      aria-required="true"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-status" aria-required="true">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="upcoming">Upcoming</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" data-testid="button-submit">
                {scheme ? "Update Scheme" : "Create Scheme"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
