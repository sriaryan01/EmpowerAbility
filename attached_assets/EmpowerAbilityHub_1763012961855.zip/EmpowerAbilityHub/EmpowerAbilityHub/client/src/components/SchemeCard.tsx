import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Volume2 } from "lucide-react";
import { Link } from "wouter";
import { useAccessibility } from "./AccessibilityContext";

export interface Scheme {
  id: string;
  title: string;
  description: string;
  category: string;
  deadline: string;
  eligibility: string;
  benefits: string;
  status: "active" | "closed" | "upcoming";
}

interface SchemeCardProps {
  scheme: Scheme;
}

export function SchemeCard({ scheme }: SchemeCardProps) {
  const { speak } = useAccessibility();

  const handleSpeak = () => {
    const text = `${scheme.title}. ${scheme.description}. Category: ${scheme.category}. Deadline: ${new Date(scheme.deadline).toLocaleDateString()}. Status: ${scheme.status}.`;
    speak(text);
  };

  const statusColor = {
    active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    closed: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400",
    upcoming: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  };

  return (
    <Card className="flex flex-col h-full hover-elevate" data-testid={`card-scheme-${scheme.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-4">
        <CardTitle className="text-lg font-semibold leading-tight" data-testid={`text-scheme-title-${scheme.id}`}>
          {scheme.title}
        </CardTitle>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 shrink-0"
          onClick={handleSpeak}
          aria-label="Read scheme details"
          data-testid={`button-speak-${scheme.id}`}
        >
          <Volume2 className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-3" data-testid={`text-scheme-description-${scheme.id}`}>
          {scheme.description}
        </p>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" data-testid={`badge-category-${scheme.id}`}>
            {scheme.category}
          </Badge>
          <Badge className={statusColor[scheme.status]} data-testid={`badge-status-${scheme.id}`}>
            {scheme.status}
          </Badge>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span data-testid={`text-deadline-${scheme.id}`}>
              Deadline: {new Date(scheme.deadline).toLocaleDateString()}
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span className="line-clamp-1">{scheme.eligibility}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-4">
        <Button asChild className="w-full" data-testid={`button-view-details-${scheme.id}`}>
          <Link href={`/schemes/${scheme.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
