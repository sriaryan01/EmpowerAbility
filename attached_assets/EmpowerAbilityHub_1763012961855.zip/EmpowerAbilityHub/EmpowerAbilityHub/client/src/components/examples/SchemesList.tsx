import { SchemesList } from "../SchemesList";
import { AccessibilityProvider } from "../AccessibilityContext";

const mockSchemes = [
  {
    id: "1",
    title: "Women Entrepreneurship Development",
    description: "Financial assistance and training for women entrepreneurs to start businesses",
    category: "Women Empowerment",
    deadline: "2025-12-31",
    eligibility: "Women aged 18-55 with business plan",
    benefits: "₹5 lakh loan at 4% interest, training",
    status: "active" as const,
  },
  {
    id: "2",
    title: "Youth Skill Development Program",
    description: "Free vocational training and job placement assistance for unemployed youth",
    category: "Youth Development",
    deadline: "2025-11-30",
    eligibility: "Youth aged 18-35, unemployed",
    benefits: "Free training, job placement support",
    status: "active" as const,
  },
  {
    id: "3",
    title: "Senior Citizen Healthcare Scheme",
    description: "Comprehensive healthcare coverage for senior citizens above 60 years",
    category: "Healthcare",
    deadline: "2026-03-31",
    eligibility: "Citizens aged 60 and above",
    benefits: "Free health checkups, medication",
    status: "upcoming" as const,
  },
];

export default function SchemesListExample() {
  return (
    <AccessibilityProvider>
      <div className="p-8">
        <SchemesList schemes={mockSchemes} />
      </div>
    </AccessibilityProvider>
  );
}
