import { SchemeDetail } from "../SchemeDetail";
import { AccessibilityProvider } from "../AccessibilityContext";

const mockScheme = {
  id: "1",
  title: "Women Entrepreneurship Development Scheme",
  description: "This comprehensive scheme provides financial assistance, training, and mentorship opportunities for women entrepreneurs across the country. The program aims to promote women-led businesses and foster economic independence through subsidized loans and skill development initiatives.",
  category: "Women Empowerment",
  deadline: "2025-12-31",
  eligibility: "Women aged 18-55 years who have a valid business plan and are willing to start or expand their business ventures. Preference given to first-time entrepreneurs and those from economically weaker sections.",
  benefits: "Subsidized loan up to ₹5 lakh at 4% annual interest rate, free business management training for 3 months, mentorship support from successful women entrepreneurs, and access to government procurement opportunities.",
  status: "active" as const,
};

export default function SchemeDetailExample() {
  return (
    <AccessibilityProvider>
      <div className="p-8">
        <SchemeDetail
          scheme={mockScheme}
          onDelete={() => console.log("Delete clicked")}
        />
      </div>
    </AccessibilityProvider>
  );
}
