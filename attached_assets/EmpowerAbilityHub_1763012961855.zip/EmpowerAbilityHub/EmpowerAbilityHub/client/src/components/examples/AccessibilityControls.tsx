import { AccessibilityControls } from "../AccessibilityControls";
import { AccessibilityProvider } from "../AccessibilityContext";
import { ThemeProvider } from "../ThemeProvider";
import { TooltipProvider } from "@/components/ui/tooltip";

export default function AccessibilityControlsExample() {
  return (
    <ThemeProvider>
      <AccessibilityProvider>
        <TooltipProvider>
          <div className="p-8 space-y-8">
            <div>
              <h2 className="text-2xl font-bold mb-4">Accessibility Controls</h2>
              <AccessibilityControls />
            </div>
            <p className="text-muted-foreground">
              Try toggling the accessibility features above to test text-to-speech, high contrast mode, and dark mode.
            </p>
          </div>
        </TooltipProvider>
      </AccessibilityProvider>
    </ThemeProvider>
  );
}
