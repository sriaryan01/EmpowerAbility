import { Dashboard } from "../Dashboard";

const mockSchemes = [
  {
    id: "1",
    title: "Women Entrepreneurship Development",
    description: "Financial assistance for women entrepreneurs",
    category: "Women Empowerment",
    deadline: "2025-12-31",
    eligibility: "Women aged 18-55",
    benefits: "₹5 lakh loan at 4% interest",
    status: "active" as const,
  },
  {
    id: "2",
    title: "Youth Skill Development Program",
    description: "Free vocational training for unemployed youth",
    category: "Youth Development",
    deadline: "2025-11-30",
    eligibility: "Youth aged 18-35",
    benefits: "Free training and job placement",
    status: "active" as const,
  },
  {
    id: "3",
    title: "Senior Citizen Healthcare",
    description: "Healthcare coverage for senior citizens",
    category: "Healthcare",
    deadline: "2026-03-31",
    eligibility: "Citizens aged 60+",
    benefits: "Free health checkups",
    status: "upcoming" as const,
  },
];

export default function DashboardExample() {
  return (
    <div className="p-8">
      <Dashboard schemes={mockSchemes} />
    </div>
  );
}
