import { SchemeForm } from "../SchemeForm";

export default function SchemeFormExample() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <SchemeForm
        onSubmit={(data) => console.log("Form submitted:", data)}
        onCancel={() => console.log("Form cancelled")}
      />
    </div>
  );
}
