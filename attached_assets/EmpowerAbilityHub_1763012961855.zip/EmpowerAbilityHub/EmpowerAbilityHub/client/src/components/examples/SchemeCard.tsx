import { SchemeCard } from "../SchemeCard";
import { AccessibilityProvider } from "../AccessibilityContext";

const mockScheme = {
  id: "1",
  title: "Women Entrepreneurship Development Scheme",
  description: "Financial assistance and training program for women entrepreneurs to start and grow their businesses with subsidized loans and mentorship opportunities.",
  category: "Women Empowerment",
  deadline: "2025-12-31",
  eligibility: "Women aged 18-55 with a valid business plan",
  benefits: "Up to ₹5 lakh loan at 4% interest, free business training, and mentorship support",
  status: "active" as const,
};

export default function SchemeCardExample() {
  return (
    <AccessibilityProvider>
      <div className="p-8 max-w-md">
        <SchemeCard scheme={mockScheme} />
      </div>
    </AccessibilityProvider>
  );
}
