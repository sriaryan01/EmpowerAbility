import { AccessibilityProvider } from "../AccessibilityContext";
import { Button } from "@/components/ui/button";

export default function AccessibilityContextExample() {
  return (
    <AccessibilityProvider>
      <div className="p-8 space-y-4">
        <h2 className="text-2xl font-bold">Accessibility Context Example</h2>
        <p className="text-muted-foreground">
          Text-to-speech and accessibility features are ready.
        </p>
        <Button>Example Button</Button>
      </div>
    </AccessibilityProvider>
  );
}
