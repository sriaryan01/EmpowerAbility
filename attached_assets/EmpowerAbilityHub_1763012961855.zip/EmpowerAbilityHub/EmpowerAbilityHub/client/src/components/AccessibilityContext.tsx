import { createContext, useContext, useState, useCallback } from "react";

interface AccessibilityContextType {
  ttsEnabled: boolean;
  toggleTTS: () => void;
  speak: (text: string) => void;
  stopSpeaking: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [ttsEnabled, setTTSEnabled] = useState(() => {
    const stored = localStorage.getItem("ttsEnabled");
    return stored === "true";
  });

  const toggleTTS = useCallback(() => {
    setTTSEnabled((prev) => {
      const newValue = !prev;
      localStorage.setItem("ttsEnabled", String(newValue));
      if (!newValue) {
        window.speechSynthesis.cancel();
      }
      return newValue;
    });
  }, []);

  const speak = useCallback((text: string) => {
    if (!ttsEnabled || !window.speechSynthesis) return;
    
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
  }, [ttsEnabled]);

  const stopSpeaking = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }, []);

  return (
    <AccessibilityContext.Provider value={{ ttsEnabled, toggleTTS, speak, stopSpeaking }}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error("useAccessibility must be used within AccessibilityProvider");
  }
  return context;
}
