import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Users, CheckCircle, Clock } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import type { Scheme } from "./SchemeCard";

interface DashboardProps {
  schemes: Scheme[];
}

export function Dashboard({ schemes }: DashboardProps) {
  const activeSchemes = schemes.filter((s) => s.status === "active").length;
  const closedSchemes = schemes.filter((s) => s.status === "closed").length;
  const upcomingSchemes = schemes.filter((s) => s.status === "upcoming").length;

  const stats = [
    {
      title: "Total Schemes",
      value: schemes.length,
      icon: FileText,
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-100 dark:bg-blue-900/30",
    },
    {
      title: "Active Schemes",
      value: activeSchemes,
      icon: CheckCircle,
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-100 dark:bg-green-900/30",
    },
    {
      title: "Upcoming",
      value: upcomingSchemes,
      icon: Clock,
      color: "text-amber-600 dark:text-amber-400",
      bgColor: "bg-amber-100 dark:bg-amber-900/30",
    },
    {
      title: "My Applications",
      value: 0,
      icon: Users,
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-100 dark:bg-purple-900/30",
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2" data-testid="text-welcome">
          Welcome to EmpowerAbility
        </h1>
        <p className="text-muted-foreground text-lg">
          Access schemes designed for Persons with Disabilities
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="hover-elevate" data-testid={`card-stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-md ${stat.bgColor}`}>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold" data-testid={`text-stat-value-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  {stat.value}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Explore disability-specific schemes, track your benefit applications, and discover new opportunities for support and empowerment.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild data-testid="button-browse-schemes">
              <Link href="/schemes">Browse All Schemes</Link>
            </Button>
            <Button variant="outline" asChild data-testid="button-my-applications">
              <Link href="/applications">My Applications</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {schemes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Recently Added Schemes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {schemes.slice(0, 3).map((scheme) => (
                <div
                  key={scheme.id}
                  className="flex items-start justify-between gap-4 p-4 rounded-md bg-muted/50 hover-elevate"
                  data-testid={`item-recent-scheme-${scheme.id}`}
                >
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{scheme.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {scheme.description}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/schemes/${scheme.id}`}>View</Link>
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
