import { Volume2, VolumeX, Contrast, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useAccessibility } from "./AccessibilityContext";
import { useTheme } from "./ThemeProvider";

export function AccessibilityControls() {
  const { ttsEnabled, toggleTTS } = useAccessibility();
  const { theme, contrastMode, toggleTheme, toggleContrastMode } = useTheme();

  return (
    <div className="flex items-center gap-2">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTTS}
            aria-label={ttsEnabled ? "Disable text-to-speech" : "Enable text-to-speech"}
            data-testid="button-toggle-tts"
            className={ttsEnabled ? "bg-primary/10 text-primary" : ""}
          >
            {ttsEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{ttsEnabled ? "Disable" : "Enable"} Text-to-Speech</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleContrastMode}
            aria-label={contrastMode === "high" ? "Disable high contrast" : "Enable high contrast"}
            data-testid="button-toggle-contrast"
            className={contrastMode === "high" ? "bg-primary/10 text-primary" : ""}
          >
            <Contrast className="h-5 w-5" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{contrastMode === "high" ? "Normal" : "High"} Contrast Mode</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            data-testid="button-toggle-theme"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{theme === "dark" ? "Light" : "Dark"} Mode</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}
