# EmpowerAbility Design Guidelines

## Design Approach
**System-Based Approach**: Material Design principles adapted for accessibility-first government/social service application. Drawing from GOV.UK design patterns for clarity and trustworthiness, combined with modern web app aesthetics.

**Core Principle**: Maximum readability and usability with zero visual barriers. Every design decision prioritizes accessibility without compromising modern aesthetics.

## Typography
- **Primary Font**: Inter (Google Fonts) - exceptional readability at all sizes
- **Hierarchy**:
  - Page titles: text-4xl font-bold (36px)
  - Section headers: text-2xl font-semibold (24px)
  - Card titles: text-lg font-semibold (18px)
  - Body text: text-base (16px) - never smaller for accessibility
  - Labels/meta: text-sm font-medium (14px)
- **Line height**: leading-relaxed (1.625) for enhanced readability
- **Letter spacing**: Default, no tight spacing

## Layout System
**Spacing Scale**: Tailwind units of 3, 4, 6, 8, 12 for consistency
- Component padding: p-6
- Section gaps: space-y-8
- Card spacing: p-6 with gap-4 for internal elements
- Page margins: px-4 md:px-8 lg:px-12

**Container Strategy**:
- Max width: max-w-7xl mx-auto for main content
- Forms/tables: max-w-5xl mx-auto
- Sidebar navigation: w-64 fixed on desktop, full-width drawer on mobile

## Application Layout

**Primary Structure**: Sidebar + Main Content
- **Header**: Fixed top bar (h-16) with app logo, user profile, accessibility controls (text-to-speech toggle, contrast mode toggle)
- **Sidebar Navigation** (Desktop): Fixed left sidebar (w-64) with Dashboard, Schemes, My Applications, Profile sections
- **Main Content Area**: pl-64 on desktop (to account for sidebar), full-width on mobile
- **Mobile**: Hamburger menu with slide-out drawer navigation

## Component Library

**Dashboard Cards**:
- Grid layout: grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Card structure: Rounded corners (rounded-lg), elevation with shadow-md, p-6
- Contains: Icon (top-left), metric number (text-3xl font-bold), label (text-sm), view link

**Scheme List/Table**:
- Clean table layout with alternating row backgrounds for scannability
- Columns: Scheme Name, Category, Deadline, Status, Actions
- Actions: View (eye icon), Edit (pencil icon), Delete (trash icon) with tooltips
- Mobile: Stacked card view instead of table

**Forms**:
- Single column layout, max-w-2xl
- Label-above-input pattern with text-sm font-medium labels
- Input spacing: space-y-6 between fields
- Input styling: Generous padding (px-4 py-3), rounded-md, clear focus states
- Required fields: Asterisk with "(required)" label
- Help text: text-sm text-gray-600 below inputs
- Submit buttons: Full-width on mobile, auto-width on desktop (right-aligned)

**Scheme Detail View**:
- Two-column layout on desktop: 2/3 content + 1/3 action sidebar
- Content sections: Overview, Eligibility, Benefits, Application Process, Documents Required
- Each section: mb-8 with clear heading (text-xl font-semibold mb-4)
- Action sidebar: Sticky positioning, includes Apply button, deadline countdown, share options, speak button (text-to-speech)

**Buttons**:
- Primary: px-6 py-3, rounded-md, font-medium
- Secondary: Same dimensions, outline style
- Icon buttons: Square (h-10 w-10), centered icon, rounded-md
- All buttons include focus-visible ring for keyboard navigation

**Accessibility Controls Bar**:
- Positioned in header (right side)
- Toggle buttons: Text-to-Speech (speaker icon), High Contrast (contrast icon), Font Size (A+ icon)
- Active state clearly indicated
- Tooltips on hover/focus

**Navigation Elements**:
- Breadcrumbs: Below header, text-sm with separator icons
- Tabs: Underline style with active indicator, h-12 height
- Pagination: Center-aligned, clear prev/next with page numbers

**Status Badges**:
- Pill-shaped (rounded-full px-3 py-1)
- Text-xs font-medium
- Semantic variations: Active, Closed, Pending, Approved

## High-Contrast Mode Specifications
When activated, transform to:
- Pure black/white backgrounds
- No gradients or subtle shades
- Border weights increase to 2px
- All text black or white (no grays)
- Focus indicators: 3px solid borders
- Button outlines: Bold, high-contrast borders

## Animations
**Minimal Usage**:
- Page transitions: None (instant for accessibility)
- Loading states: Simple spinner, no elaborate animations
- Hover states: Subtle brightness/opacity changes only
- Focus states: Instant ring appearance

## Images
**No hero images** - This is a functional application, not a marketing site.
**Icon Usage**: Heroicons (via CDN) throughout for actions, categories, and navigation
**Avatars**: Circular, default placeholder for user profiles
**Document previews**: Thumbnail cards with file type icons

## Accessibility Features Integration
- **Text-to-Speech**: Visible speaker icons on all major content blocks (scheme details, cards, forms)
- **Keyboard Navigation**: All interactive elements accessible via Tab, visible focus rings (ring-2 ring-offset-2)
- **ARIA Labels**: Comprehensive labeling for screen readers
- **Skip Links**: "Skip to main content" link at page top
- **Form Validation**: Error messages announced to screen readers, clear visual indicators

This design creates a professional, trustworthy, and highly accessible government/social service application that prioritizes user needs while maintaining modern web standards.