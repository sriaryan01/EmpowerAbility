import { getDB } from "../db";
import { type User, type UpsertUser, type InsertUser, type Scheme, type InsertScheme, users, schemes } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User methods - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Scheme methods
  getAllSchemes(): Promise<Scheme[]>;
  getScheme(id: string): Promise<Scheme | undefined>;
  createScheme(scheme: InsertScheme): Promise<Scheme>;
  updateScheme(id: string, scheme: Partial<InsertScheme>): Promise<Scheme | undefined>;
  deleteScheme(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods - required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const result = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Scheme methods
  async getAllSchemes(): Promise<Scheme[]> {
    return await db.select().from(schemes);
  }

  async getScheme(id: string): Promise<Scheme | undefined> {
    const result = await db.select().from(schemes).where(eq(schemes.id, id));
    return result[0];
  }

  async createScheme(insertScheme: InsertScheme): Promise<Scheme> {
    const result = await db.insert(schemes).values(insertScheme).returning();
    return result[0];
  }

  async updateScheme(id: string, updateData: Partial<InsertScheme>): Promise<Scheme | undefined> {
    const result = await db
      .update(schemes)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(schemes.id, id))
      .returning();
    return result[0];
  }

  async deleteScheme(id: string): Promise<boolean> {
    const result = await db.delete(schemes).where(eq(schemes.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();
